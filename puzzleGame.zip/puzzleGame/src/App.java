import com.game.ui.LoginJFrame;

public class App {
    public static void main(String[] args) {

        new LoginJFrame();

        //new RegisterJFrame();

        //new GameJFrame();
    }
}
