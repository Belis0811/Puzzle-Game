package com.game.ui;

import javax.swing.*;

public class RegisterJFrame extends JFrame {

    public RegisterJFrame(){

        //set ui size
        this.setSize(488,500);
        //set the title of the game
        this.setTitle("Register");
        //set this interface on the top
        this.setAlwaysOnTop(true);
        //set the ui in the middle
        this.setLocationRelativeTo(null);
        //set close mode
        this.setDefaultCloseOperation(3);
        //make it visible
        this.setVisible(true);
        getContentPane();
    }

}
