package com.game.ui;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

public class GameJFrame extends JFrame implements KeyListener, ActionListener {

    //create two dem array
    int [] [] data = new int[4][4];

    //the position of the blank square
    int x =0;
    int y =0;

    //define a variable to show path
    String path="F:\\java\\puzzleGame\\image\\animal\\animal3\\";

    int[][] win ={
            {1,2,3,4},
            {5,6,7,8},
            {9,10,11,12},
            {13,14,15,0}
    };

    int step = 0;

    //create two object related to the menu
    JMenuItem animal = new JMenuItem("animal");
    JMenuItem sport = new JMenuItem("sport");
    JMenuItem replayItem = new JMenuItem("Replay the game");
    JMenuItem reLoginItem = new JMenuItem("Login the game again");
    JMenuItem closeItem = new JMenuItem("Close the game");

    JMenuItem accountItem = new JMenuItem("Public Account");

    public GameJFrame(){

        //initiate the frame
        initJFrame();

        //initiate menu
        initJMenuBar();

        //initiate data
        initData();

        //initiate image loading
        initImage();


        //make it visible
        this.setVisible(true);
    }




    private void initData() {
        //define an array
        int[] tempArr={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
        Random r = new Random();
        for (int i = 0; i < tempArr.length; i++) {
            int index = r.nextInt(tempArr.length);
            int temp = tempArr[i];
            tempArr[i]=tempArr[index];
            tempArr[index]=temp;
        }


        //add data to array
        for (int i = 0; i < tempArr.length; i++) {
            if(tempArr[i]==0){
                x=i/4;
                y=i%4;
            }
            data[i/4][i%4]=tempArr[i];
        }

    }

    private void initImage() {
        //clear existed pic
        this.getContentPane().removeAll();

        if(victory()){
            JLabel winJLabel = new JLabel(new ImageIcon("F:\\java\\puzzleGame\\image\\win.png"));
            winJLabel.setBounds(203,283,197,73);
            this.getContentPane().add(winJLabel);
        }

        JLabel stepCount = new JLabel("Steps: "+step);
        stepCount.setBounds(50,30,100,20);
        this.getContentPane().add(stepCount);

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                int number=data[i][j];
                //create a picture
                JLabel jLabel = new JLabel(new ImageIcon(path+number+".jpg"));
                //set pic position
                jLabel.setBounds(105*j+83,105*i+134,105,105);
                //add bound to label
                //bevelBorder: 0-raise 1-lowed
                jLabel.setBorder(new BevelBorder(1));
                //add pic to label
                this.getContentPane().add(jLabel);
                //load next picture
            }
        }

        //add background pic
        ImageIcon bg = new ImageIcon("F:\\java\\puzzleGame\\image\\background.png");
        JLabel background = new JLabel(bg);
        background.setBounds(40,40,508,560);
        this.getContentPane().add(background);

        //refresh pic
        this.getContentPane().repaint();

    }

    private void initJMenuBar() {
        //set menu obj
        JMenuBar jMenuBar = new JMenuBar();

        //create two options on the menu
        JMenu functionJMenu = new JMenu("Function");
        JMenu aboutJMenu = new JMenu("About us");

        JMenu changePic = new JMenu("Change another picture");

        changePic.add(animal);
        changePic.add(sport);

        //add items to the menu
        functionJMenu.add(changePic);
        functionJMenu.add(replayItem);
        functionJMenu.add(reLoginItem);
        functionJMenu.add(closeItem);

        aboutJMenu.add(accountItem);

        //bound events to every menu bar
        replayItem.addActionListener(this);
        reLoginItem.addActionListener(this);
        closeItem.addActionListener(this);
        accountItem.addActionListener(this);
        animal.addActionListener(this);
        sport.addActionListener(this);

        //add menu to menu bar
        jMenuBar.add(functionJMenu);
        jMenuBar.add(aboutJMenu);

        this.setJMenuBar(jMenuBar);
    }

    private void initJFrame() {
        //set ui size
        this.setSize(603,680);
        //set the title of the game
        this.setTitle("puzzle game v1.0");
        //set this interface on the top
        this.setAlwaysOnTop(true);
        //set the ui in the middle
        this.setLocationRelativeTo(null);
        //set close mode
        this.setDefaultCloseOperation(3);
        //cancel default position
        this.setLayout(null);
        //add key listener
        this.addKeyListener(this);
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        if(code==65){//press a
            this.getContentPane().removeAll();
            JLabel all = new JLabel(new ImageIcon(path+"all.jpg"));
            all.setBounds(83,134,420,420);
            this.getContentPane().add(all);
            //add background pic
            ImageIcon bg = new ImageIcon("F:\\java\\puzzleGame\\image\\background.png");
            JLabel background = new JLabel(bg);
            background.setBounds(40,40,508,560);
            this.getContentPane().add(background);

            //refresh pic
            this.getContentPane().repaint();

        }

    }

    @Override
    public void keyReleased(KeyEvent e) {

        //judge if game has won
        if(victory()){
            return;
        }

        //judge up, down, left, right
        int code = e.getKeyCode();
       // System.out.println(code);
        if(code==37){
            System.out.println("move left");
            if(y==3){
                return;
            }
            data[x][y]=data[x][y+1];
            data[x][y+1]=0;
            y++;
            step++;
            initImage();
        } else if (code==38) {
            System.out.println("move up");
            if(x==3){
                return;
            }
            data[x][y]=data[x+1][y];
            data[x+1][y]=0;
            x++;
            step++;
            initImage();
        }else if (code==39) {
            System.out.println("move right");
            if(y==0){
                return;
            }
            data[x][y]=data[x][y-1];
            data[x][y-1]=0;
            y--;
            step++;
            initImage();
        }else if (code==40) {
            System.out.println("move down");
            if(x==0){
                return;
            }
            data[x][y]=data[x-1][y];
            data[x-1][y]=0;
            x--;
            step++;
            initImage();
        } else if (code==65) {
            initImage();
        } else if (code==87) { //press w
            data = new int[][]{
                    {1,2,3,4},
                    {5,6,7,8},
                    {9,10,11,12},
                    {13,14,15,0}
            };
            initImage();
        }

    }

    public boolean victory(){
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                if(data[i][j]!=win[i][j]){
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        if(obj==replayItem){
            System.out.println("Replay the game");
            //clear step
            step=0;
            //random array sequence
            initData();
            //reload image
            initImage();

        } else if (obj==reLoginItem) {
            System.out.println("ReLogin");

            //return login ui
            this.setVisible(false);
            new LoginJFrame();

        } else if (obj==closeItem) {
            System.out.println("Close");
            //close VM
            System.exit(0);

        } else if (obj==accountItem) {
            System.out.println("Account");

            //create pop up window
            JDialog jDialog = new JDialog();
            //create a container
            JLabel jLabel = new JLabel(new String("  author: Belis contact no: 323-447-5062"));
            jDialog.getContentPane().add(jLabel);
            jDialog.setSize(344,344);
            jDialog.setAlwaysOnTop(true);
            jDialog.setLocationRelativeTo(null);
            jDialog.setModal(true);
            jDialog.setVisible(true);
        } else if (obj==animal) {
            System.out.println("animal");
            Random r = new Random();
            int index = r.nextInt(7)+1;
            path="F:\\java\\puzzleGame\\image\\animal\\animal"+index+"\\";
            //clear step
            step=0;
            //random array sequence
            initData();
            //reload image
            initImage();
        } else if (obj==sport) {
            System.out.println("sport");
            Random r = new Random();
            int index = r.nextInt(9)+1;
            path="F:\\java\\puzzleGame\\image\\sport\\sport"+index+"\\";
            //clear step
            step=0;
            //random array sequence
            initData();
            //reload image
            initImage();
        }
    }
}
